<?php
require 'config.php';

mysqli_query($conn, 
"UPDATE `session` SET `etat` = 'annulée' 
WHERE date_debut = CURRENT_DATE 
AND (SELECT COUNT(*) FROM inscription i WHERE i.id_session = session.id_session) <3 
AND etat = 'en cours d\'inscription' ");

mysqli_query($conn, 
"UPDATE `session` SET `etat` = 'en cours' 
WHERE date_debut = CURRENT_DATE 
AND (SELECT COUNT(*) FROM inscription i WHERE i.id_session = session.id_session) >=3 
AND ( etat = 'en cours d\'inscription' OR etat = 'inscription achevée' )");

mysqli_query($conn, 
"UPDATE `session` SET `etat` = 'cloturée' 
WHERE date_fin = CURRENT_DATE 
AND etat = 'en cours'");
