<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="css/home.css">
</head>

<body>

<?php
require 'config.php';
if(!empty($_SESSION["id_apprenant"])){
    $id = $_SESSION["id_apprenant"];
    $result = mysqli_query($conn, "SELECT * FROM apprenant WHERE id_apprenant = $id");
    $row = mysqli_fetch_assoc($result);
    ?>

    <!-- ======= Header/Navbar ======= -->
    <nav class="navbar navbar-default navbar-trans navbar-expand-lg ">
    <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>



    <a class="navbar-brand text-brand" href="home.php">GesFormations</a>

    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
        <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link active" href="home.php">Home</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="Formations.php">Formations</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="">Contact</a>
        </li>
        </ul>
    </div>



    <button class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-target="#loginModal">
        <a href="Profile-personal.php" style="margin-right: 1rem; color: black; text-decoration :none;"><span><?php echo $row["firstname"] ; ?></span><i class="fa-solid fa-user mx-1"></i></a>

        <a href="logout-user.php" style="color: black;"><i class="fa-solid fa-right-from-bracket"></i></a>
    </button>

    </div>
</nav>
<?php
}
else{
    ?>
    
    <!-- ======= Header/Navbar ======= -->
<nav class="navbar navbar-default navbar-trans navbar-expand-lg">
    <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>



    <a class="navbar-brand text-brand" href="home.php">GesFormations</a>

    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
        <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link active" href="home.php">Home</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="Formations.php">Formations</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="">Contact</a>
        </li>
        </ul>
    </div>



    <button class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-target="#loginModal">
        <a href="signup.php" class ="btn btn-outline-dark" style="margin-right: 1rem; text-decoration :none;">SignUp</a>

        <a href="login.php" class="btn btn-dark" style="text-decoration :none;">Login</a>
    </button>

    </div>
</nav>
    <?php
}
?>


<!--  Cover Title-->
    <div class="backgroundPhoto bg-image p-5 text-center shadow-1-strong mb-3 text-white">

    <h1 class="">Develop your Mind & Skills </h1>
    <a class="btnMore btn btn-dark px-5 py-2" href="formations.php" style="">More</a>

    </div>


<!-- 2 Cards -->

<div class="albumPrds album py-3">
    <h2 class="text-center">Available Sessions</h2>

<div class="latestsProducts container">

<?php


$formations = "SELECT  DISTINCT f.id_formation,sujet,categorie,masse_horaire,description FROM session s 
                INNER JOIN formation f ON f.id_formation = s.id_formation
                WHERE s.etat = 'en cours d\\'inscription'
                ORDER BY s.id_formation DESC LIMIT 6";


$result = mysqli_query($conn, $formations);

if( mysqli_num_rows ( $result ) > 0 ){

echo ' <div class="latestsProductsdiv row">';

while($row = mysqli_fetch_assoc($result)) {

    $id_formation = $row["id_formation"];

    echo '
<div class="col-md-4 x">
    <form method = "GET" action = "formation-details.php" class="card formationCards"  style=" background-color: white;">
    <div class="card-body">
        <h4 class="card-title">' .$row['sujet']. '</h4>
        <p class="card-text"><strong>Categorie :</strong> <span class = "duration">'  .$row['categorie']. '</span></p>
        <p class="card-text"><strong>Masse Horaire :</strong><span class = "duration"> '  .$row['masse_horaire']. 'h</span></p>
        <p class="card-text">'  .$row['description']. '</p>

        <input type="hidden" name="id_formation" type = "submit" value ="'.$id_formation.'">
        <input class="btn " type="submit" value = "More" style = "width : 50% ;background-color:#1fae51;color:white;margin-top:5%">

    </div>
    
    </form>
    </div>';

}


echo '</div>';
}


?>




</div>

</div>

<div class=" my-3">

<h2 class="text-center">About Us</h2>

<div class="row d-flex justify-content-around py-5" style="width:100%;margin:auto;">

            <!-- card 1 -->

            <div class="cardsAbout pb-5 px-5 col-md-3" style="background-color:#212A3E;color:white;">

            <div class="">
            <h3 class="mt-4">Read our blog</h3>

            <div class="py-3" style="color:white">
                <p>Want to know what we’ve been up to lately? Check out the Udemy blog to get the scoop on the latest news, ideas and projects, and more.</p>
            </div>

            </div>
            <i class="fa-solid fa-arrow-right mx-4"></i>
            <a class="cardslink" href="https://about.udemy.com/blog/" target="_blank" rel="noopener" >Read now</a>

            </div>

            <!-- card 2  -->

            <div class="cardsAbout pb-5 px-5 col-md-3" style="background-color:#212A3E;color:white;">

            <div class="">
            <h3 class="mt-4">See our research</h3>

            <div class="py-3" style="color:white">
                <p>We’re committed to improving lives through learning. Dig into our original research to learn about the forces that are shaping the modern workplace.</p>
            </div>

            </div>
            <i class="fa-solid fa-arrow-right mx-4"></i>
            <a class="cardslink" href="https://about.udemy.com/blog/" target="_blank" rel="noopener" >Learn more</a>

            </div>

            <!-- card 3 -->

            <div class="cardsAbout pb-5 px-5 col-md-3" style="background-color:#212A3E;color:white;">

            <div class="">
            <h3 class="mt-4">Work with us</h3>

            <div class="py-3" style="color:white">
                <p>At Udemy, we’re all learners and instructors. We live out our values every day to create a culture that is diverse, inclusive, and committed to helping employees thrive.</p>
            </div>

            </div>
            <i class="fa-solid fa-arrow-right mx-4"></i>
            <a class="cardslink" href="https://about.udemy.com/blog/" target="_blank" rel="noopener" >Learn more</a>

            </div>


</div>
</div>






<footer>

<div class="text-center p-4" style="background-color: #212A3E; color:white;">
    © 2023 Copyright:
    <a class="text-reset fw-bold" href="home.php">GesFormations.com</a>
</div>
    <!-- Copyright -->
    
</footer>

</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/d78c31e99a.js" crossorigin="anonymous"></script>
    </html>