<?php
require 'config.php';
if(!empty($_SESSION["id_formateur"])){
    $id_formateur = $_SESSION["id_formateur"];
    $result = mysqli_query($conn, "SELECT * FROM formateur WHERE id_formateur = $id_formateur");
    $row = mysqli_fetch_assoc($result);

}

$etat_session = $_POST["etat"];
$id_session = $_POST["id_session"];
$id_apprenant = $_POST["id_apprenant"];
$result_apprenant = $_POST["validation"];

if($etat_session == "cloturée"){

    for($i=0;$i<count($id_apprenant);$i++){
        
        $app= $id_apprenant[$i];
        $result = $result_apprenant[$i];

    $upd = mysqli_query($conn, "UPDATE `inscription` SET 
    `resultat` = '$result', `date_validation` = CURRENT_DATE 
    WHERE `id_apprenant` = '$app' AND id_session = '$id_session'");

}   
}
header("Location:session_details_formateur.php?etat=".$etat_session."&id_session=".$id_session);
exit();


?>