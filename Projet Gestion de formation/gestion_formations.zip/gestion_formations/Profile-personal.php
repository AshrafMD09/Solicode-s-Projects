<?php
require 'config.php';
if(!empty($_SESSION["id_apprenant"])){
    $id = $_SESSION["id_apprenant"];
    $result = mysqli_query($conn, "SELECT * FROM apprenant WHERE id_apprenant = $id");
    $row = mysqli_fetch_assoc($result);
}
else{
    header("Location: login.php");
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="css/Profile-personal.css">
</head>

<body>


    <!-- ======= Header/Navbar ======= -->
    <nav class="navbar navbar-default navbar-trans navbar-expand-lg ">
    <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>



    <a class="nav-link navbar-brand text-brand" href="home.php">GesFormations</a>

    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault" >
        <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link " href="home.php">Home</a>
        </li>

        <li class="nav-item">
            <a class="nav-link active" href="Formations.php">Formations</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="">Contact</a>
        </li>
        </ul>
    </div>



    <button class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-target="#loginModal">
        <a href="Profile-personal.php" style="margin-right: 1rem; color: white; text-decoration :none;"><span><?php echo $row["firstname"] ; ?></span><i class="fa-solid fa-user mx-1"></i></a>

        <a href="logout-user.php" style="color: white;"><i class="fa-solid fa-right-from-bracket"></i></a>
    </button>

    </div>
</nav>

<!-- Side-Bar -->

<div class="row profileLinksSection  text-center">
    

    <div class=" profileLinksdiv col-md-6">    <a href="Profile-personal.php" class="profileLinks" style="text-decoration: underline;">Personal Informations</a>
    </div>
    
    <div class=" profileLinksdiv col-md-6">    <a href="Profile-inscription.php" class="profileLinks">Mes Inscriptions</a>
    </div>

    <!-- <div class=" profileLinksdiv col-md-4">    <a href="" class="profileLinks">Historiques</a>
    </div> -->


</div>

    <!-- Infos -->

        <div class="container mt-3">
        <div class=" formSU ">
            
    <form class="row" action = "edit-profile-personal.php" method ="POST">

            <div class="col-md-6">
                <div class="inputs">
                    <label for="firstname"><strong>First Name</strong></label>
                    <input class="form-control" type="text" placeholder="First Name" name="firstname"  value = "<?php echo $row["firstname"] ; ?>" required> </div>
                </div>

            <div class="col-md-6">
                <div class="inputs">
                    <label for="lastname"><strong>Last Name</strong></label>
                    <input class="form-control" type="text" placeholder="Last Name" name="lastname" value = "<?php echo $row["lastname"] ; ?>" required> </div>
                </div>

            <div class="col-md-12">
                <div class="inputemail">
                    <label for="email"><strong>Email</strong></label>
                    <input class="form-control" type="email" placeholder="Email" name="email" value = "<?php echo $row["email"] ; ?>" required> </div>
                </div>

            <div class="col-md-6">
                <div class="inputs">
                    <label for="Password"><strong>Password</strong></label>
                    <input class="form-control" type="password" placeholder="Password" name="password" value = "" > </div>
                </div>

            <div class="col-md-6">
                <div class="inputs">
                    <label for="confirmpassword"><strong>Confirme Password</strong></label>
                    <input class="form-control" type="password" placeholder="Confirme Password" name="confirmpassword" value = "" > </div>
                </div>
    
            <div class="mt-3 gap-2 d-flex justify-content">
                <button class="px-3 btn  " name = "submit" type = "submit" style = "background-color:#1fae51;color:white;">Save</button> 
            </div>
    </form>
        </div>
    

</div>



</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/d78c31e99a.js" crossorigin="anonymous"></script>
</html>