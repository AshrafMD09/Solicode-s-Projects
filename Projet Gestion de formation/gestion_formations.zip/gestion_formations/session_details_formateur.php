<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formation details</title>
    <link rel="stylesheet" href="css/session-details_formateur.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    
</head>

<body>
<?php
require 'config.php';
if(!empty($_SESSION["id_formateur"])){
    $id_formateur = $_SESSION["id_formateur"];
    $result = mysqli_query($conn, "SELECT * FROM formateur WHERE id_formateur = $id_formateur");
    $row = mysqli_fetch_assoc($result);
?>

    <!-- ======= Header/Navbar ======= -->
    <nav class="navbar navbar-default navbar-trans navbar-expand-lg ">
    <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <a class="nav-link navbar-brand text-brand" href="formations_formateur.php">GesFormations</a>

    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault" >
        <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link active" href="Formations_formateur.php">Formations</a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="">Contact</a>
        </li>
        </ul>
    </div>

    <button class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-target="#loginModal">
        <a href="" style="margin-right: 1rem; color: white; text-decoration :none;"><span><?php echo $row["firstname"] ; ?></span><i class="fa-solid fa-user mx-1"></i></a>

        <a href="logout-formateur.php" style="color: white;"><i class="fa-solid fa-right-from-bracket"></i></a>
    </button>

    </div>
</nav>
<?php
}
else{
    header("Location: login_formateur.php");
}
?>

    <div class="mt-3 w-75 m-auto">
        
        <?php $id_session = $_GET["id_session"]; ?>

    <h1 class="text-center">Les Apprenants en Session <?php echo $id_session; ?> </h1>

        <?php

$result = mysqli_query($conn,"SELECT * FROM inscription i 
INNER JOIN apprenant a ON a.id_apprenant = i.id_apprenant
INNER JOIN session s ON s.id_session  = i.id_session
WHERE s.id_session = $id_session");

$etat_session = $_GET['etat'];


if( mysqli_num_rows($result ) > 0 ){

    
    ?>
    
    <table class="table table-dark mt-5">
    <thead>
    <tr>
    <th scope="col">#</th>
    <th scope="col">ID-user</th>
    <th scope="col">First name</th>
    <th scope="col">Last name</th>
    <th scope="col">Date Validation</th>
    <th scope="col">Result</th>
    </tr>
    </thead>

<?php

$hh=0;
while($row = mysqli_fetch_assoc($result)) {
$id_session = $row['id_session'];
$id_apprenant = $row['id_apprenant'];
$hh++;

?>

    <tbody>
    <form action="validation_formateur.php" method="POST">
    <tr >
        <th class = ""><?php echo $hh; ?></th>
        <th class = ""><?php echo $row['id_apprenant']; ?></th>
        <th class = ""><?php echo $row['firstname']; ?></th>
        <th class = ""><?php echo $row['lastname']; ?></th>
        <th class = ""><?php echo $row['date_validation']; ?></th>
        <th class = "">
        
        <select class="btn btn-light" name="validation[]" id = "validation">

        <?php if($row["resultat"] == "Valide"){?>

                <option selected value="Valide" name = "">Valide</option>
                <option  value="Not Valide" name = "">Not Valide</option>

            <?php }
            else{ ?>

                <option  value="Valide" name = "">Valide</option>
                <option selected  value="Not Valide" name = "">Not Valide</option>

            <?php } ?>
            
        </select>
        </th>
    </tr>
    <input name="etat" value="<?=$etat_session?>" class="d-none" >
    <input name="id_apprenant[]" value="<?=$id_apprenant?>" class="d-none" >
    <input type="hidden" name="id_session" value="<?=$id_session ?>">

<?php
}
echo '</table>';
echo'<button class="btn btn-success px-5" name="setresult" type="submit">Set Result</button>';
echo '</form>';

}

else{

echo'<div class="alert alert-warning latestsProductsdiv row mt-5" role="alert">
        <h1 class ="text-center">There is no one in this Session :)</h1>
    </div>';
}



?>
</div>

</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/d78c31e99a.js" crossorigin="anonymous"></script>
</html>