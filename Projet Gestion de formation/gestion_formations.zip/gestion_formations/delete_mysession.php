<?php

require 'config.php';
if(!empty($_SESSION["id_apprenant"])){
    $id_apprenant = $_SESSION["id_apprenant"];
    $result = mysqli_query($conn, "SELECT * FROM apprenant WHERE id_apprenant = $id_apprenant");
    $row = mysqli_fetch_assoc($result);
}

$id_session = $_GET["id_session"] ;
    

$hey = mysqli_query($conn," DELETE FROM `inscription` 
WHERE `inscription`.`id_apprenant` = '$id_apprenant' AND `inscription`.`id_session` = '$id_session' ");


header("Location: Profile-inscription.php");
exit();

?>